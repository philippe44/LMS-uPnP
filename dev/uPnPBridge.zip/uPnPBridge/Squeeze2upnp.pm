package Plugins::uPnPBridge::Squeeze2upnp;

use strict;

use Proc::Background;
use File::ReadBackwards;
use File::Spec::Functions;

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use XML::Simple;

my $prefs = preferences('plugin.upnpbridge');
my $log   = logger('plugin.upnpbridge');

my $squeeze2upnp;
my $binary;

sub binaries {
	my $os = Slim::Utils::OSDetect::details();

	if ($os->{'os'} eq 'Linux') {
		if ($os->{'osArch'} =~ /x86_64/) {
			return qw(squeeze2upnp-x86-64);
		}
		if ($os->{'binArch'} =~ /i386/) {
			return qw(squeeze2upnp-x86);
		}
		if ($os->{'binArch'} =~ /arm/) {
			return qw(squeeze2upnp-armv6hf);
		}
		# fallback to offering all linux options for case when architecture detection does not work
		return qw(squeeze2upnp-x86-64 squeeze2upnp-x86 squeeze2upnp-armv6hf);
	}
	if ($os->{'os'} eq 'Darwin') {
		return qw(squeeze2upnp-osx-x86);
	}
	if ($os->{'os'} eq 'Windows') {
		return qw(squeeze2upnp);
	}
}

sub bin {
	my $class = shift;

	my @binaries = $class->binaries;

	if (scalar @binaries == 1) {
		return $binaries[0];
	}

	if (my $b = $prefs->get("bin")) {
		for my $bin (@binaries) {
			if ($bin eq $b) {
				return $b;
			}
		}
	}

	return $binaries[0] =~ /squeeze2upnp-osx/ ? $binaries[0] : undef;
}

sub start {
	my $class = shift;

	my $bin = $class->bin || do {
		$log->warn("no binary set");
		return;
	};

	my @params;
	my $logging;

=no more output option
	if ($prefs->get('output') ne '') {
		push @params, ("-o", $prefs->get('output'));
	}
=cut	

	push @params, ("-Z");
	
	if ($prefs->get('debugs') ne '') {
		push @params, ("-d", $prefs->get('debugs') . "=debug");
	}

	if ($prefs->get('logging') || $prefs->get('debugs') ne '') {
		push @params, ("-f", $class->logFile);
		$logging = 1;
	}
	
	if (-e $class->configFile) {
		push @params, ("-x", $class->configFile);
	}
	
	if ($prefs->get('opts') ne '') {
		push @params, split(/\s+/, $prefs->get('opts'));
	}
	
	my $path = Slim::Utils::Misc::findbin($bin) || do {
		$log->debug("$bin not found");
		return;
	};

	my $path = Slim::Utils::OSDetect::getOS->decodeExternalHelperPath($path);
		
	if (!-e $path) {
		$log->debug("$bin not executable");
		return;
	}
	
	push @params, @_;

	if ($logging) {
		open(my $fh, ">>", $class->logFile);
		print $fh "\nStarting Squeeze2upnp: $path @params\n";
		close $fh;
	}
	
	eval { $squeeze2upnp = Proc::Background->new({ 'die_upon_destroy' => 1 }, $path, @params); };

	if ($@) {

		$log->warn($@);

	} else {
		Slim::Utils::Timers::setTimer($class, Time::HiRes::time() + 1, sub {
			if ($squeeze2upnp && $squeeze2upnp->alive) {
				$log->debug("$bin running");
				$binary = $path;
			}
			else {
				$log->debug("$bin NOT running");
			}
		});
	}
}

sub stop {
	my $class = shift;

	if ($squeeze2upnp && $squeeze2upnp->alive) {
		$log->info("killing squeeze2upnp");
		$squeeze2upnp->die;
	}
}

sub alive {
	return ($squeeze2upnp && $squeeze2upnp->alive) ? 1 : 0;
}

sub wait {
	$log->info("waiting for squeeze2upnp to end");
	$squeeze2upnp->wait
}

sub restart {
	my $class = shift;

	$class->stop;
	$class->start;
}

=no more devices
sub devices {
	return unless $binary;

	# run "squeeze2upnp -l" to get devices and parse result
	my $query = "$binary -l";
	my @devices = `$query`;

	my @output;

	for my $line (@devices) {
		if (my ($name, $desc) = $line =~ /\s+(.*?)\s+\-\s+(.*)/) {
			if ($name !~ /^\d+$/) {
				# ALSA
				push @output, { name => $name, desc => $desc };
			} else {
				# Port Audio
				#$desc =~ s/ \[.*?\]//; # temp strip additional text from squeeze2upnp 1.3
				push @output, { name => $desc, desc => $name };
			}
		}
	}

	return \@output;
}
=cut

sub logFile {
	return catdir(Slim::Utils::OSDetect::dirsFor('log'), "upnpbridge.log");
}

sub configFile {
	return catdir(Slim::Utils::OSDetect::dirsFor('prefs'), $prefs->get('configfile'));
}

sub logHandler {
	my ($client, $params, undef, undef, $response) = @_;

	$response->header("Refresh" => "10; url=" . $params->{path} . ($params->{lines} ? '?lines=' . $params->{lines} : ''));
	$response->header("Content-Type" => "text/plain; charset=utf-8");

	my $body = '';
	my $file = File::ReadBackwards->new(logFile());
	
	if ($file){

		my @lines;
		my $count = $params->{lines} || 100;

		while ( --$count && (my $line = $file->readline()) ) {
			unshift (@lines, $line);
		}

		$body .= join('', @lines);

		$file->close();			
	};

	return \$body;
}

sub configHandler {
	my ($client, $params, undef, undef, $response) = @_;

	$response->header("Content-Type" => "text/xml; charset=utf-8");

	my $body = '';
	
	if (-e configFile) {
		open my $fh, '<', configFile;
		
		read $fh, $body, -s $fh;
		close $fh;
	}	

	return \$body;
}

1;
