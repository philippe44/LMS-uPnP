package Plugins::uPnPBridge::Settings;

use strict;

use File::Spec::Functions;
use base qw(Slim::Web::Settings);
use XML::Simple;
use Data::Dumper;
use Slim::Utils::Prefs;
use Slim::Utils::Log;


my $prefs = preferences('plugin.upnpbridge');
my $log   = logger('plugin.upnpbridge');
my @xmlmain = qw(upnp_scan_interval upnp_scan_timeout);
my @xmldevice = qw(name mac stream_length accept_nexturi seek_after_pause buffer_dir buffer_limit sample_rate codecs L24_format flac_header enabled upnp_remove_count send_metadata volume_on_play volume_curve);

sub name { 'PLUGIN_UPNPBRIDGE' }

sub page { 'plugins/uPnPBridge/settings/basic.html' }

sub handler {
	my ($class, $client, $params, $callback, @args) = @_;

	my $update;
			
	if ($params->{'saveSettings'}) {

		# only set autorun if turning it on as other params are hidden and don't get returned
		my @bool  = qw(autorun logging);
		my @other = qw(output bin debugs opts);
		my $skipxml;
				
		for my $param (@bool) {
			
			my $val = $params->{ $param } ? 1 : 0;
			
			if ($val != $prefs->get($param)) {
					
				$prefs->set($param, $val);
				$update = 1;
				
				if ($param eq 'autorun') {
					require Plugins::uPnPBridge::Squeeze2upnp;
				}
	
			}
		}
		
		# check that the config file name has not changed first
		for my $param (@other) {
		
			if ($params->{ $param } ne $prefs->get($param)) {
			
				$prefs->set($param, $params->{ $param });
				$update = 1;
			}
		}
		
		if ($params->{ 'configfile' } ne $prefs->get('configfile')) {
		
			$prefs->set('configfile', $params->{ 'configfile' });
			$update = 1;
			$skipxml = 1;
		}	
		
		if ($params->{ 'delconfig' }) {
				
			require Plugins::uPnPBridge::Squeeze2upnp;				
			my $conf = Plugins::uPnPBridge::Squeeze2upnp->configFile($class);
			unlink $conf;							
			$log->info("deleting configuration $conf");
			
			$update = 1;
		}
		
		if ($params->{ 'genconfig' }) {
				
			require Plugins::uPnPBridge::Squeeze2upnp;				
			my $conf = Plugins::uPnPBridge::Squeeze2upnp->configFile($class);
			Plugins::uPnPBridge::Squeeze2upnp->stop;
			Plugins::uPnPBridge::Squeeze2upnp->start( "-i", $conf );
			Plugins::uPnPBridge::Squeeze2upnp->wait;
										
			$skipxml = $params->{ 'xmlparams'} ? 0 : 1;
			
			$log->info("generation configuration $conf");
			$update = 1;
		}	
		
		my $xmlconfig = readconfig($class, KeyAttr => 'device');
				
		if ($xmlconfig and !$skipxml and ($params->{'seldevice'} eq $params->{'prevseldevice'})) {
		
			$log->info('Writing XML:', $params->{'seldevice'});
			for my $p (@xmlmain) {
				
				if ($params->{ $p } eq '') {
					delete $xmlconfig->{ $p };
				} else {
					$xmlconfig->{ $p } = $params->{ $p };
				}	
			}
			
			$log->info("current: ", $params->{'seldevice'}, "previous: ", $params->{'prevseldevice'});
			
			#save common parameters
			if ($params->{'seldevice'} eq '.common.') {
			
				for my $p (@xmldevice) {
					if ($params->{ $p } eq '') {
						delete $xmlconfig->{ common }->{ $p };
					} else {
						$xmlconfig->{ common }->{ $p } = $params->{ $p };
					}
				}	
				
			# save player specific parameters
			} else {
			
				$params->{'devices'} = \@{$xmlconfig->{'device'}};
				my $device = findUDN($params->{'seldevice'}, $params->{'devices'});
				
				for my $p (@xmldevice) {
					if ($params->{ $p } eq '') {
						delete $device->{ $p };
					} else {
						$device->{ $p } = $params->{ $p };
					}
				}	
				
			}

			# get enabled status for all device, except the selected one
			foreach my $device (@{$xmlconfig->{'device'}}) {
				if ($device->{'udn'} ne $params->{'seldevice'}) {
					my $enabled = $params->{ 'enabled.'.$device->{ 'udn' } };
					$device->{'enabled'} = defined $enabled ? $enabled : 0;
				}	
			}
			
			$log->info("writing XML config");
			XMLout($xmlconfig, RootName => "squeeze2upnp", NoSort => 1, NoAttr => 1, OutputFile => Plugins::uPnPBridge::Squeeze2upnp->configFile($class));
			$update = 1;
#			$log->debug(Dumper($xmlconfig));
		}	
	}

	# something has been updated, XML array is up-to-date anyway, but need to write it
	if ($update) {

		$log->debug("updating");
				
		$prefs->get('autorun') ? Plugins::uPnPBridge::Squeeze2upnp->restart : Plugins::uPnPBridge::Squeeze2upnp->stop;

		Slim::Utils::Timers::setTimer($class, Time::HiRes::time() + 1, sub {
			$class->handler2( $client, $params, $callback, @args);		  
		});

	#no update detected or first time looping
	} else {

		$log->debug("not updating");
		$class->handler2( $client, $params, $callback, @args);		  
	}

	return undef;
}

sub handler2 {
	my ($class, $client, $params, $callback, @args) = @_;

	if ($prefs->get('autorun')) {

		$params->{'binary'}   = Plugins::uPnPBridge::Squeeze2upnp->bin;
		$params->{'binaries'} = [ Plugins::uPnPBridge::Squeeze2upnp->binaries ];
		$params->{'running'}  = Plugins::uPnPBridge::Squeeze2upnp->alive;

	} else {

		$params->{'running'} = 0;
	}

	for my $param (qw(autorun output bin opts debugs logging configfile)) {
		$params->{ $param } = $prefs->get($param);
	}
	
	$params->{'configpath'} = Slim::Utils::OSDetect::dirsFor('prefs');
	$params->{'arch'} = Slim::Utils::OSDetect::OS();
	
	my $xmlconfig = readconfig($class, KeyAttr => 'device');
		
	#load XML parameters from config file	
	if ($xmlconfig) {
	
		$params->{'devices'} = \@{$xmlconfig->{'device'}};
		unshift(@{$params->{'devices'}}, {'name' => '[default parameters]', 'udn' => '.common.'});
		
		$log->info("reading config: ", $params->{'seldevice'});
		$log->debug(Dumper($params->{'devices'}));
				
		#read global parameters
		for my $p (@xmlmain) {
			#$params->{ $p } = defined $xmlconfig->{ $p } ? $xmlconfig->{ $p } : 'default';
			$params->{ $p } = $xmlconfig->{ $p };
			$log->debug("reading: ", $p, " ", $xmlconfig->{ $p });
		}
		
		# read either common parameters or device-specific
		if (!defined $params->{'seldevice'} or ($params->{'seldevice'} eq '.common.')) {
			$params->{'seldevice'} = '.common.';
			
			for my $p (@xmldevice) {
				#$params->{ $p } = defined $xmlconfig->{common}->{ $p } ? $xmlconfig->{common}->{ $p } : '';
				$params->{ $p } = $xmlconfig->{common}->{ $p };
			}	
		} else {
			my $device = findUDN($params->{'seldevice'}, $params->{'devices'});
			
			for my $p (@xmldevice) {
				#$params->{ $p } = defined $device->{ $p } ? $device->{ $p } : '';
				$params->{ $p } = $device->{ $p };
			}
		}
		$params->{'prevseldevice'} = $params->{'seldevice'};
		$params->{'xmlparams'} = 1;
	} else {
	
		$params->{'xmlparams'} = 0;
	}
	
	$callback->($client, $params, $class->SUPER::handler($client, $params), @args);
}

sub findUDN {
	my $udn = shift(@_);
	my $listpar = shift(@_);
	my @list = @{$listpar};
	
	while (@list) {
		my $p = pop @list;
		if ($p->{ 'udn' } eq $udn) { return $p; }
	}
	return undef;
}

sub readconfig {
	my ($class,@args) = @_;
	my $ret;
	
	require Plugins::uPnPBridge::Squeeze2upnp;				
	my $file = Plugins::uPnPBridge::Squeeze2upnp->configFile($class);
	if (-e $file) {
		$ret = XMLin($file, ForceArray => 0, KeepRoot => 0, NoAttr => 1, @args);
	}	
	return $ret;
}

1;
