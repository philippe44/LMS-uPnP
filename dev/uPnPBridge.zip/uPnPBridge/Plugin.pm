package Plugins::uPnPBridge::Plugin;

use strict;

use base qw(Slim::Plugin::Base);

use Slim::Utils::Prefs;
use Slim::Utils::Log;

my $prefs = preferences('plugin.upnpbridge');

$prefs->init({ autorun => 0, opts => '', debugs => '', logging => 0, bin => undef, configfile => "upnpbridge.xml"});

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.upnpbridge',
	'defaultLevel' => 'WARN',
	'description'  => Slim::Utils::Strings::string('PLUGIN_UPNPBRIDGE'),
}); 

sub initPlugin {
	my $class = shift;

	$class->SUPER::initPlugin(@_);

#	if (Slim::Utils::OSDetect::OS() =~ /win/) {
#		require Plugins::uPnPBridge::DownloadLibs;
#		Plugins::uPnPBridge::DownloadLibs->checkLibs($class);
#	}

#	if ($prefs->get('loc')) {
#		require Plugins::uPnPBridge::LocalFile;
#		Slim::Player::ProtocolHandlers->registerHandler('file', 'Plugins::uPnPBridge::LocalFile');
#	}

	if ($prefs->get('autorun')) {
		require Plugins::uPnPBridge::Squeeze2upnp;
		Plugins::uPnPBridge::Squeeze2upnp->start;
	}
	
	if (!$::noweb) {
		require Plugins::uPnPBridge::Settings;
		Plugins::uPnPBridge::Settings->new;
		Slim::Web::Pages->addPageFunction("^upnpbridge.log", \&Plugins::uPnPBridge::Squeeze2upnp::logHandler);
		Slim::Web::Pages->addPageFunction("^configuration", \&Plugins::uPnPBridge::Squeeze2upnp::configHandler);
	}
}

sub shutdownPlugin {
	if ($prefs->get('autorun')) {
		Plugins::uPnPBridge::Squeeze2upnp->stop;
	}
}

1;
